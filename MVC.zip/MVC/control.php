<?php
class Employes extends DB {
  function getSelect(){
    return $this->getRequete("SELECT * FROM `tbl_employe`");
  }
}
?>