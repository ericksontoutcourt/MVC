<!DOCTYPE htm>
<html>
<body>
  <h1> Liste des employés </h1>
<ul><?php
  // $resultat ici énoncé de la requête
  // $cnx connexion à la base de données
  require "model.php";
  require "control.php";
  $employes = new Employes();
  foreach ($employes->getSelect() as $employe) {
    echo "<li>" 
              . $employe['emp_id'] . " : " 
              . $employe['emp_pnom'] . " - " 
              . $employe['emp_nom'] . " - "
              . $employe['emp_tel'] .
           "</li>";
  }
  // FERMER LA CONNEXION  À LA BASE DE DONNÉES
  $resultat = null;
  $cnx = null;
?></ul>
</body>
</html>
